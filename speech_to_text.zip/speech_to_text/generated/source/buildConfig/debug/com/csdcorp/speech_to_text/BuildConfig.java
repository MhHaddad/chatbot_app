/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.csdcorp.speech_to_text;

public final class BuildConfig {
  public static final boolean DEBUG = Boolean.parseBoolean("true");
  public static final String LIBRARY_PACKAGE_NAME = "com.csdcorp.speech_to_text";
  public static final String BUILD_TYPE = "debug";
}

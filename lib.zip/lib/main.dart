import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:chatbot/Chatbot.dart';
import 'package:chatbot/animation.dart';
import 'package:text_to_speech/text_to_speech.dart';
import 'package:rive/rive.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  // This widget is the root of your application.
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late stt.SpeechToText _speech;
  String _text = '';
  String _text2 = '';
  bool _isListening = false;
  Chatbot chat = Chatbot();
  TextToSpeech tts = TextToSpeech();
  late RiveAnimationController _controller;
  int _duration = 0;
  
  void _toggle() => _controller.isActive = !_controller.isActive;

  void runListening(){
    Future.delayed(const Duration(seconds: 5), () {
      _listen();
    }
    );
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _speech = stt.SpeechToText();
    _controller = SimpleAnimation('talk', autoplay: false);
    _toggle();
    runListening();

  }
  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: RiveAnimation.asset(
              'assets/face_robot_v1.riv',
              fit: BoxFit.cover,
              controllers: [_controller],
              ),
      ),
    );

  }
void _listen() async{
    if(!_isListening){
      _text = '';
      bool available = await _speech.initialize(
        onStatus: (val) => print('onStatus: $val'),
        onError: (val) => print ('onError: $val'),
      );
      if(available){
        setState(() => _isListening = true);
        _speech.listen(
          onResult: (val) => setState((){
             _text = val.recognizedWords;
          }),
        );
      }
      Future.delayed(const Duration(seconds: 5), () async{
        _speech.stop();
        print(_text);
        if(_text != '' && _text != null){
          _text2 = await chat.runAssistant(text: _text);
          if(_text2 != ''){
            _duration = Anim().setDuration(Text: _text2);
            tts.setVolume(1.0);
            tts.setPitch(1.0);
            tts.speak(_text2);
          }
          else{
            _duration = 0;
          }
          if(_duration != 0){
            _toggle();
            Future.delayed( Duration(seconds: _duration), (){
              _toggle();
              _isListening = false;
              Future.delayed(const Duration(seconds: 3), () {
                _listen();
              }
              );
            });
          }
          else{
            _isListening = false;
            Future.delayed(const Duration(seconds: 5), () {
              _listen();
            }
            );
          }
        }
        else{
          _isListening = false;
          Future.delayed(const Duration(seconds: 5), () {
            _listen();
          }
          );
        }
      });
    }
}


}






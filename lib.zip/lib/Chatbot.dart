import 'package:ibm_watson_assistant/ibm_watson_assistant.dart';

class Chatbot {

  Future<String> runAssistant ({required String text}) async{
    String _response = '';
    final String ASSISTANT_ID = '164e6a24-8c05-41d0-8c21-f254332b0dc4';
    final String ASSISTANT_URL = 'https://api.eu-de.assistant.watson.cloud.ibm.com/instances/bed6d568-11d4-4758-b7d5-4b796f3d8533';
    final String API_KEY ='fHdMjy_iuNF3Jea3X-ZZnvO_fT_3mIY1Pu8-gIcD1Cw1';



    final auth = IbmWatsonAssistantAuth(
      assistantId: ASSISTANT_ID,
      url: ASSISTANT_URL,
      apikey: API_KEY,
    );

    final bot = IbmWatsonAssistant(auth);

    final sessionId = await bot.createSession();

    try{
      final botRes = await bot.sendInput(text, sessionId: sessionId);
      print(botRes.output!.generic!.first.text);
      _response = botRes.responseText!;
      bot.deleteSession(sessionId!);
      return _response;
    }catch(e){
      return '';
    }

  }
}
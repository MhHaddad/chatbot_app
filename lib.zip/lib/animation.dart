class Anim{

  int setDuration({required String Text}){
    List<String> answers = ['Hello. How can I help you?',
      'Hello! how can I help you?',
     'It is the website to control the robot. For arm control, you can control the arm of the robot by degrees, which you put in the motors, and you can activate the arm. For movement control, you can control the movement of the robot.',
    "The challenge about two robots with an arm and they have one balloon. You can control one robot. Your objective to pop the opponent's balloon.",
    "I have built the website with Bootstrap studio and Laravel 8. For chatbot, I have built chatbot by IBM Watson assistant.",
    "If we determine the time of the tournament, We will send you a message via email.",
    "There is not any fee for the tournament, so it is free.",
    "Is it good or bad?",
    "Thank you for your feedback.",
    "I am a bot.",
    "I am a chatbot assistant, so I do not have jokes.",
    "The best technique is to wait for the best chance to pop the ballon's opponent.",
    "I am glad to help you",
    "You are welcome",
    "I am here for any question",
    "It is my pleasure",
    "I didn't understand. You can try rephrasing.",
    "Can you reword your statement? I'm not understanding.",
    "I didn't get your meaning."];
    List<int> duration = [2, 2, 11, 8, 7, 5, 3, 1, 2, 1, 3, 4, 2, 1, 2, 2, 3, 3, 2];
    //find the duration of text
    for(int i = 0; i < answers.length; i++){
      if(answers[i] == Text){
        return duration[i];
      }
    }
    return 0;
  }

}